erg
===

Command line client for querying range servers.

## Install

    # OSX
    brew tap square/self
    brew install erg

    erg --help
