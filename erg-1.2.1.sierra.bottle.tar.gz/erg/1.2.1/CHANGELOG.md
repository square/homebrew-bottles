# Erg History

# 1.2.1 - 04 Nov 2016

* Fix arg clash on -h
* Move to square repo

# 1.2.0 - 26 Oct 2015

* Non-zero exit code when the server does not return an HTTP 200 success code.
* Expanded output is naturally sorted (9/10/11 rather than 10/11/9).

# 1.1.1 - 28 Oct 2014

* Internal refactor to expose `Erg` type for use by other libraries.
* Add SSL support via `--ssl` flag and `RANGE_SSL` environment variable.

# 1.1.0 - 16 May 2014

* Respect `RANGE_HOST` and `RANGE_PORT` environment variables.

# 1.0.1 - 4 May 2014

* Output usage when no arguments provided.
* Add `--sort` and `--no-sort` options.

# 1.0.0 - 4 May 2014

* Initial release
