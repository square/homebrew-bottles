erg
===

Command line client for querying range servers.

## Install

    # OSX
    brew tap xaviershay/self
    brew install erg

    erg --help
