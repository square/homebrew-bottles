# Erg History

# 1.1.1 - 28 Oct 2014

* Internal refactor to expose `Erg` type for use by other libraries.
* Add SSL support via `--ssl` flag and `RANGE_SSL` environment variable.

# 1.1.0 - 16 May 2014

* Respect `RANGE_HOST` and `RANGE_PORT` environment variables.

# 1.0.1 - 4 May 2014

* Output usage when no arguments provided.
* Add `--sort` and `--no-sort` options.

# 1.0.0 - 4 May 2014

* Initial release
