# Erg History

# 1.0.1 - 4 May 2014

* Output usage when no arguments provided.
* Add `--sort` and `--no-sort` options.

# 1.0.0 - 4 May 2014

* Initial release
